// MIT License
//
// Copyright (c) 2023-Present - Violet Hansen - (aka HotCakeX on GitHub) - Email Address: spynetgirl@outlook.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// See here for more information: https://github.com/HotCakeX/Harden-Windows-Security/blob/main/LICENSE
//

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using AppControlManager.IntelGathering;
using AppControlManager.Others;
using AppControlManager.SimulationMethods;
using AppControlManager.XMLOps;
using Microsoft.UI.Xaml.Controls;

namespace AppControlManager.Main;

internal static class AppControlSimulation
{

	// Extensions that are not supported by Authenticode. So if these files are not allowed by hash, they are not allowed at all
	private static readonly HashSet<string> unsignedExtensions = new(StringComparer.OrdinalIgnoreCase)
		{
			".ocx", ".bat", ".bin"
		};

	/// <summary>
	/// An Aux method that calls the main method then checks the result to make sure all files are allowed, if they are then returns true, otherwise returns false
	/// </summary>
	/// <param name="filePaths"></param>
	/// <param name="xmlFilePath"></param>
	/// <param name="noCatalogScanning"></param>
	/// <returns></returns>
	internal static bool Invoke(List<string>? filePaths, string xmlFilePath, bool noCatalogScanning)
	{
		// Call the main method to get the verdicts
		ConcurrentDictionary<string, SimulationOutput> Results = Invoke(filePaths, null, xmlFilePath, noCatalogScanning, false, null, 2);

		// See if there are any unauthorized files
		IEnumerable<SimulationOutput> ResultsAfterFilter = Results.Values.Where(R => !R.IsAuthorized);

		// If there are no results where the IsAuthorized is false then return true, else return false
		return !ResultsAfterFilter.Any();
	}


	internal static void ExportToCsv(ConcurrentDictionary<string, SimulationOutput> finalResults, string filePath)
	{
		// Create a list for CSV lines
		List<string> csvLines = [];

		// Create header instead of using reflection to get the properties' names of the SimulationOutput class
		string header = "\"Path\",\"Source\",\"IsAuthorized\",\"SignerID\",\"SignerName\",\"SignerCertRoot\",\"SignerCertPublisher\",\"SignerScope\",\"SignerFileAttributeIDs\",\"MatchCriteria\",\"SpecificFileNameLevelMatchCriteria\",\"CertSubjectCN\",\"CertIssuerCN\",\"CertNotAfter\",\"CertTBSValue\",\"FilePath\"";
		csvLines.Add(header);

		// Iterate through the SimulationOutput instances and format each line
		foreach (SimulationOutput output in finalResults.Values)
		{
			List<string> values =
			[
				$"\"{output.Path}\"",
				$"\"{output.Source}\"",
				$"\"{output.IsAuthorized}\"",
				$"\"{output.SignerID}\"",
				$"\"{output.SignerName}\"",
				$"\"{output.SignerCertRoot}\"",
				$"\"{output.SignerCertPublisher}\"",
				$"\"{output.SignerScope}\"",
				output.SignerFileAttributeIDs is not null ? $"\"{string.Join(",", output.SignerFileAttributeIDs)}\"" : "\"\"",
				$"\"{output.MatchCriteria}\"",
				$"\"{output.SpecificFileNameLevelMatchCriteria}\"",
				$"\"{output.CertSubjectCN}\"",
				$"\"{output.CertIssuerCN}\"",
				$"\"{output.CertNotAfter}\"",
				$"\"{output.CertTBSValue}\"",
				$"\"{output.FilePath}\""
			];

			csvLines.Add(string.Join(",", values));
		}

		// Write to file
		File.WriteAllLines(filePath, csvLines);
	}


	/// <summary>
	/// The main method that performs the App Control Simulation.
	/// </summary>
	/// <param name="filePaths"></param>
	/// <param name="folderPaths"></param>
	/// <param name="xmlFilePath"></param>
	/// <param name="noCatalogScanning"></param>
	/// <param name="csvOutput"></param>
	/// <param name="catRootPath"></param>
	/// <param name="threadsCount"> The number of concurrent threads used to run the simulation </param>
	/// <param name="UIProgressBar"></param>
	/// <returns></returns>
	/// <exception cref="ArgumentNullException"></exception>
	/// <exception cref="FileNotFoundException"></exception>
	/// <exception cref="InvalidOperationException"></exception>
	internal static ConcurrentDictionary<string, SimulationOutput> Invoke(
		List<string>? filePaths,
		List<string>? folderPaths,
		string? xmlFilePath,
		bool noCatalogScanning,
		bool csvOutput,
		List<string>? catRootPath,
		ushort threadsCount = 2,
		ProgressBar? UIProgressBar = null)
	{

		if (xmlFilePath is null)
		{
			throw new ArgumentNullException(nameof(xmlFilePath), "The XML file path cannot be null.");
		}

		if (!File.Exists(xmlFilePath))
		{
			throw new FileNotFoundException("The XML file does not exist.", xmlFilePath);
		}

		// Ensure threadsCount is at least 1
		threadsCount = Math.Max((ushort)1, threadsCount);

		Logger.Write($"Running App Control Simulation with {threadsCount} threads count");

		// Read the content of the XML file into a string
		string xmlContent = File.ReadAllText(xmlFilePath);

		// Convert the string to XML Document
		XmlDocument XMLData = new();
		XMLData.LoadXml(xmlContent);


		// Get the signer information from the XML
		List<SignerX> SignerInfo = GetSignerInfo.Get(XMLData);

		#region Region FilePath Rule Checking
		Logger.Write("Checking see if the XML policy has any FilePath rules");

		HashSet<string> FilePathRules = XmlFilePathExtractor.GetFilePaths(xmlFilePath);

		bool HasFilePathRules = FilePathRules.Count > 0;
		#endregion


		// A dictionary where each key is a hash and value is the .Cat file path where the hash was found in
		ConcurrentDictionary<string, string> AllSecurityCatalogHashes = [];

		if (!noCatalogScanning)
		{
			// Get the security catalog data to include in the scan
			AllSecurityCatalogHashes = CatRootScanner.Scan(catRootPath, threadsCount);
		}
		else
		{
			Logger.Write("Skipping Security Catalogs in the Simulation.");
		}

		Logger.Write("Getting the Hash values of all the file rules based on hash in the supplied xml policy file");

		// All Hash values of all the file rules based on hash in the supplied xml policy file
		HashSet<string> AllHashTypesFromXML = GetFileHashes.Get(XMLData);

		Logger.Write("Getting all of the file paths of the files that App Control supports, from the user provided directory");

		(IEnumerable<FileInfo>, int) CollectedFiles = FileUtility.GetFilesFast(
			folderPaths?.Select(dir => new DirectoryInfo(dir)).ToArray(),
			filePaths?.Select(file => new FileInfo(file)).ToArray(),
			null);

		// Make sure the selected directories and files contain files with the supported extensions
		if (CollectedFiles.Item2 == 0)
		{
			throw new InvalidOperationException("There are no files in the selected directory that are supported by the App Control engine.");
		}

		Logger.Write("Looping through each supported file");

		// The counter variable to track processed files
		int processedFilesCount = 0;

		// The count of all of the files that are going to be processed
		double AllFilesCount = CollectedFiles.Item2;

		// The Concurrent Dictionary contains any and all of the Simulation results
		// Keys of it are the file paths which aren't important, values are the important items needed at the end of the simulation
		ConcurrentDictionary<string, SimulationOutput> FinalSimulationResults = new(threadsCount, CollectedFiles.Item2);


		#region Region Making Sure No AllowAll Rule Exists

		if (CheckForAllowAll.Check(xmlFilePath))
		{
			Logger.Write($"The supplied XML file '{xmlFilePath}' contains a rule that allows all files.");

			_ = FinalSimulationResults.TryAdd(xmlFilePath, new SimulationOutput(
				null,
				"AllowAllRule",
				true,
				null,
				null,
				null,
				null,
				null,
				null,
				"Has AllowAll rule",
				null,
				null,
				null,
				null,
				null,
				null));

			// Return the result and do not proceed further
			return FinalSimulationResults;
		}
		#endregion


		// Create a timer to update the progress bar every 2 seconds.
		Timer? progressTimer = null;

		if (UIProgressBar is not null)
		{
			progressTimer = new(state =>
			   {
				   // Read the current value in a thread-safe manner.
				   int current = Volatile.Read(ref processedFilesCount);

				   // Calculate the percentage complete
				   int currentPercentage = (int)(current / AllFilesCount * 100);

				   _ = UIProgressBar.DispatcherQueue.TryEnqueue(() =>
				   {
					   UIProgressBar.Value = Math.Min(currentPercentage, 100);
				   });
			   }, null, 0, 2000);
		}

		try
		{
			// split the file paths by ThreadsCount which by default is 2 and minimum 1
			IEnumerable<FileInfo[]> SplitArrays = CollectedFiles.Item1.Chunk((int)Math.Ceiling(AllFilesCount / threadsCount));

			// List of tasks to run in parallel
			List<Task> tasks = [];

			// Loop over each chunk of data
			foreach (FileInfo[] chunk in SplitArrays)
			{
				// Run each chunk of data in a different thread
				tasks.Add(Task.Run(() =>
				{
					// Loop over the current chunk of data
					foreach (FileInfo CurrentFilePath in chunk)
					{
						// Increment the processed file count safely
						_ = Interlocked.Increment(ref processedFilesCount);

						// Check see if the file's hash exists in the XML file regardless of whether it's signed or not
						// This is because App Control policies sometimes have hash rules for signed files too
						// So here we prioritize being authorized by file hash over being authorized by Signature

						if (HasFilePathRules && FilePathRules.Contains(CurrentFilePath.FullName))
						{
							_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
								new SimulationOutput(
									CurrentFilePath.Name,
									"FilePath",
									true,
									null,
									null,
									null,
									null,
									null,
									null,
									"Allowed By File Path",
									null,
									null,
									null,
									null,
									null,
									CurrentFilePath.FullName
								));

							// Move to the next file
							continue;
						}

						string CurrentFilePathHashSHA256;
						string CurrentFilePathHashSHA1;

						try
						{
							CodeIntegrityHashes CurrentFileHashResult = CiFileHash.GetCiFileHashes(CurrentFilePath.FullName);

							CurrentFilePathHashSHA256 = CurrentFileHashResult.SHA256Authenticode!;
							CurrentFilePathHashSHA1 = CurrentFileHashResult.SHa1Authenticode!;
						}
						catch
						{
							_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
								new SimulationOutput(
									CurrentFilePath.Name,
									"Signer",
									false,
									null,
									null,
									null,
									null,
									null,
									null,
									"Not processed, Inaccessible file",
									null,
									null,
									null,
									null,
									null,
									CurrentFilePath.FullName
								));

							// Move to the next file
							continue;
						}

						// if the file's hash exists in the XML file then add the file's path to the allowed files and do not check anymore that whether the file is signed or not
						if (AllHashTypesFromXML.Contains(CurrentFilePathHashSHA256) || AllHashTypesFromXML.Contains(CurrentFilePathHashSHA1))
						{
							_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
								new SimulationOutput(
									CurrentFilePath.Name,
									"Hash",
									true,
									null,
									null,
									null,
									null,
									null,
									null,
									"Hash Level",
									null,
									null,
									null,
									null,
									null,
									CurrentFilePath.FullName
								));

							// Move to the next file
							continue;
						}

						// If the file's extension is not supported by Authenticode and it wasn't allowed by file hash then it's not allowed and no reason to check its signature
						else if (unsignedExtensions.Contains(CurrentFilePath.Extension))
						{
							_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
								new SimulationOutput(
									CurrentFilePath.Name,
									"Unsigned",
									false,
									null,
									null,
									null,
									null,
									null,
									null,
									"Not Allowed",
									null,
									null,
									null,
									null,
									null,
									CurrentFilePath.FullName
								));

							// Move to the next file
							continue;
						}

						// If the file's hash does not exist in the supplied XML file, then check its signature
						else
						{
							try
							{
								List<AllFileSigners> FileSignatureResults = AllCertificatesGrabber.GetAllFileSigners(CurrentFilePath.FullName);

								// If there is no result then check if the file is allowed by a security catalog
								if (FileSignatureResults.Count == 0)
								{
									string? MatchedHashResult = null;

									if (!noCatalogScanning)
									{
										_ = AllSecurityCatalogHashes.TryGetValue(CurrentFilePathHashSHA1, out string? CurrentFilePathHashSHA1CatResult);
										_ = AllSecurityCatalogHashes.TryGetValue(CurrentFilePathHashSHA256, out string? CurrentFilePathHashSHA256CatResult);

										MatchedHashResult = CurrentFilePathHashSHA1CatResult ?? CurrentFilePathHashSHA256CatResult;
									}

									if (!noCatalogScanning && MatchedHashResult is not null)
									{
										AllFileSigners CatalogSignerDits = AllCertificatesGrabber.GetAllFileSigners(MatchedHashResult).First();

										nint handle = CatalogSignerDits.Chain.ChainElements[0].Certificate.Handle;

										// The file is authorized by a security catalog on the system
										_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
											new SimulationOutput(
												CurrentFilePath.Name,
												"Catalog Signed",
												true,
												null,
												null,
												null,
												null,
												null,
												null,
												"Catalog Hash",
												MatchedHashResult,
												CryptoAPI.GetNameString(handle, CryptoAPI.CERT_NAME_SIMPLE_DISPLAY_TYPE, null, false),
												CryptoAPI.GetNameString(handle, CryptoAPI.CERT_NAME_SIMPLE_DISPLAY_TYPE, null, true),
												CatalogSignerDits.Chain.ChainElements[0].Certificate.NotAfter.ToString(CultureInfo.InvariantCulture),
												CertificateHelper.GetTBSCertificate(CatalogSignerDits.Chain.ChainElements[0].Certificate),
												CurrentFilePath.FullName
											));

										// Move to the next file
										continue;
									}
									else
									{
										// The file is not signed and is not allowed by hash using Security Catalog
										_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
											new SimulationOutput(
												CurrentFilePath.Name,
												"Unsigned",
												false,
												null,
												null,
												null,
												null,
												null,
												null,
												"Not Allowed",
												null,
												null,
												null,
												null,
												null,
												CurrentFilePath.FullName
											));

										// Move to the next file
										continue;
									}
								}
								else
								{
									// Use the Compare method to process it

									// The EKU OIDs of the primary signer of the file, just like the output of the Get-AuthenticodeSignature cmdlet, the ones that App Control policy uses for EKU-based authorization
									List<string> ekuOIDs = LocalFilesScan.GetOIDs(FileSignatureResults);

									SimulationInput inPutSim = new(
										CurrentFilePath, // Path of the signed file
										GetCertificateDetails.Get(FileSignatureResults), //  Get all of the details of all certificates of the signed file
										SignerInfo, // The entire Signer Info of the App Control Policy file
										ekuOIDs);

									SimulationOutput ComparisonResult = Arbitrator.Compare(inPutSim);

									_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName, ComparisonResult);
								}
							}
							catch (HashMismatchInCertificateException)
							{
								_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
									new SimulationOutput(
										CurrentFilePath.Name,
										"Signer",
										false,
										null,
										null,
										null,
										null,
										null,
										null,
										"Hash Mismatch",
										null,
										null,
										null,
										null,
										null,
										CurrentFilePath.FullName
									));

								// Move to the next file
								continue;
							}

							// Handle any other error by storing the file path and the reason for the error to display to the user
							catch (Exception ex)
							{
								// If the file is signed but has unknown signature status
								_ = FinalSimulationResults.TryAdd(CurrentFilePath.FullName,
									new SimulationOutput(
										CurrentFilePath.Name,
										"Signer",
										false,
										null,
										null,
										null,
										null,
										null,
										null,
										$"UnknownError: {ex.Message}",
										null,
										null,
										null,
										null,
										null,
										CurrentFilePath.FullName
									));

								// Move to the next file
								continue;
							}
						}
					}
				}));
			}

			// Wait for all tasks to complete without making the method async
			// The method is already being called in an async/await fashion
			Task.WaitAll([.. tasks]);

			// Dispose the timer and update the progress bar to 100%
			if (UIProgressBar is not null)
			{
				_ = UIProgressBar.DispatcherQueue.TryEnqueue(() => UIProgressBar.Value = 100);
			}

		}
		finally
		{   // Dispose of the timer
			progressTimer?.Dispose();
		}

		// If user chose to output the results to CSV file
		if (csvOutput)
		{
			ExportToCsv(FinalSimulationResults, Path.Combine(GlobalVars.UserConfigDir, @$"AppControl Simulation output {DateTime.Now:yyyy-MM-dd HH-mm-ss}.csv"));
		}

		return FinalSimulationResults;

	}
}
